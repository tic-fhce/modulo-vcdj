package com.sgd.sgdfback._01_test.producto;

import java.util.List;
import java.util.Optional;

public interface ProductoService {
    List<Producto> obtenerTodos();

    Optional<Producto> obtenerPorId(Long id);

    Producto guardar(Producto producto);

    Producto actualizar(Long id, Producto producto);

    void eliminar(Long id);

    Producto actualizarColumna(Long id, String columna, Object valor);
}

